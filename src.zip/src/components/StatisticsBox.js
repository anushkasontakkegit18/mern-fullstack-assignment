import React, { useEffect, useState } from 'react';
import axios from 'axios';

import {
    Chart as ChartJS,
    CategoryScale,
    LinearScale,
    BarElement,
    Title,
    Tooltip,
    Legend
  } from 'chart.js';
  
  ChartJS.register(
    CategoryScale,
    LinearScale,
    BarElement,
    Title,
    Tooltip,
    Legend
  );
  
  
  const StatisticsBox = ({ selectedMonth }) => {
    const [statistics, setStatistics] = useState({
      totalSales: 0,
      totalSoldItems: 0,
      totalUnsoldItems: 0
    });
  
    useEffect(() => {
      fetchStatistics();
    }, [selectedMonth]);
  
    const fetchStatistics = async () => {
      try {
        const res = await axios.get(`http://localhost:3000/api/statistics/${selectedMonth}`);
        setStatistics(res.data);
      } catch (error) {
        console.error(error);
      }
    };
  
    return (
      <div className="statistics-box">
        <h3>Statistics for {selectedMonth}</h3>
        <div>Total Sales: ${statistics.totalSales}</div>
        <div>Total Sold Items: {statistics.totalSoldItems}</div>
        <div>Total Unsold Items: {statistics.totalUnsoldItems}</div>
      </div>
    );
  };
  
  export default StatisticsBox;
  
