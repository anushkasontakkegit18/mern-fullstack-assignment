import React, { useState, useEffect } from 'react';
import axios from 'axios';

const TransactionsTable = ({ selectedMonth }) => {
  const [transactions, setTransactions] = useState([]);
  const [searchText, setSearchText] = useState('');
  const [page, setPage] = useState(1);
  const [totalPages, setTotalPages] = useState(1);

  useEffect(() => {
    fetchTransactions(); // Fetch transactions whenever month, page, or searchText changes
  }, [selectedMonth, page, searchText]);

  const fetchTransactions = async () => {
    try {
      const res = await axios.get('http://localhost:3000/api/transactions', {
        params: {
          month: selectedMonth,
          page,
          search: searchText // Pass the search text to the API
        },
      });
      setTransactions(res.data.transactions);
      setTotalPages(Math.ceil(res.data.total / 10)); // Calculate total pages
    } catch (error) {
      console.error(error);
    }
  };

  const handleSearch = (e) => {
    setSearchText(e.target.value);
    setPage(1);  // Reset to first page on search
  };

  const handleClearSearch = () => {
    setSearchText('');
    setPage(1);  // Reset to first page
    fetchTransactions(); // Fetch initial list for the selected month
  };

  return (
    <div className="transactions-container">
      <h2>Transactions for {selectedMonth}</h2>
      <input 
        type="text" 
        placeholder="Search by title/description/price" 
        value={searchText} 
        onChange={handleSearch} 
        className="search-box"
      />
      <button 
        onClick={handleClearSearch} 
        className="clear-search-btn"
        disabled={!searchText} // Disable if search text is empty
      >
        Clear Search
      </button>
      
      <table className="transactions-table">
        <thead>
          <tr>
            <th>Title</th>
            <th>Description</th>
            <th>Price</th>
            <th>Date of Sale</th>
            <th>Sold</th>
          </tr>
        </thead>
        <tbody>
          {transactions.length > 0 ? (
            transactions.map((transaction) => (
              <tr key={transaction._id}>
                <td>{transaction.title}</td>
                <td>{transaction.description}</td>
                <td>${transaction.price}</td>
                <td>{new Date(transaction.dateOfSale).toLocaleDateString()}</td>
                <td>{transaction.sold ? 'Yes' : 'No'}</td>
              </tr>
            ))
          ) : (
            <tr><td colSpan="5">No transactions found</td></tr>
          )}
        </tbody>
      </table>

      <div className="pagination">
        <button onClick={() => setPage(page - 1)} disabled={page === 1}>Previous</button>
        <button onClick={() => setPage(page + 1)} disabled={page === totalPages}>Next</button>
      </div>
    </div>
  );
};

export default TransactionsTable;
