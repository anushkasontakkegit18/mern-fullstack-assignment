import React, { useState } from 'react';
import TransactionsTable from './components/TransactionsTable';
import StatisticsBox from './components/StatisticsBox';
import BarChart from './components/BarChart';
import './App.css';

const App = () => {
  // Default to March as required in the task
  const [selectedMonth, setSelectedMonth] = useState('March');

  return (
    <div className="app-container">
      <h1>Transactions Dashboard</h1>
      <div className="month-select">
        <label htmlFor="month">Select Month: </label>
        <select 
          id="month"
          value={selectedMonth}
          onChange={(e) => setSelectedMonth(e.target.value)}
        >
          {['January', 'February', 'March', 'April', 'May', 'June', 
            'July', 'August', 'September', 'October', 'November', 'December'].map((month) => (
            <option key={month} value={month}>{month}</option>
          ))}
        </select>
      </div>

      <div className="data-sections">
        {/* Transactions Table */}
        <TransactionsTable selectedMonth={selectedMonth} />

        {/* Statistics Box */}
        <StatisticsBox selectedMonth={selectedMonth} />

        {/* Bar Chart */}
        <BarChart selectedMonth={selectedMonth} />
      </div>
    </div>
  );
};

export default App;
